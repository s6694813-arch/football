const http = require("http"), fs = require("fs"), path = require("path"), WebSocket = require("ws");
const server = http.createServer((req,res)=>{
  let file = req.url === "/" ? "index.html" : req.url.split("?")[0].slice(1);
  let full = path.join(__dirname,file);
  if(!full.startsWith(__dirname)){res.writeHead(403);return res.end();}
  fs.readFile(full,(err,data)=>{
    if(err){res.writeHead(404);return res.end("Not found");}
    let ext=path.extname(full);
    res.writeHead(200,{"Content-Type":ext===".js"?"text/javascript":ext===".css"?"text/css":"text/html"});
    res.end(data);
  });
});
const wss=new WebSocket.Server({server});
const clients=new Map(); let serial=1;
const S={players:{},ball:{x:450,y:340,vx:0,vy:0,owner:null},score:[0,0],message:"Waiting for opponent..."};
const W=900, FLOOR=365;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function broadcast(){const data=JSON.stringify({type:"state",state:S});for(const c of wss.clients)if(c.readyState===1)c.send(data);}
function kickoff(){
  const ids=[...clients.keys()];
  for(const id of ids){let p=S.players[id];if(p){p.x=p.slot===0?250:650;p.y=FLOOR;p.vx=0;p.vy=0;p.jump=false;p.hasBall=p.slot===0;}}
  S.ball={x:250,y:FLOOR-25,vx:0,vy:0,owner:ids[0]||null};
  S.message="PLAYER 1 has the ball! Get to the end zone!";
}
wss.on("connection",ws=>{
  if(clients.size>=2){ws.send(JSON.stringify({type:"full"}));ws.close();return;}
  const id=String(serial++),slot=clients.size;clients.set(id,ws);
  S.players[id]={id,slot,name:"PLAYER "+(slot+1),x:slot===0?250:650,y:FLOOR,vx:0,vy:0,dir:slot===0?1:-1,hasBall:slot===0,input:{left:false,right:false,jump:false,pass:false}};
  if(clients.size===1)S.ball.owner=id;
  if(clients.size===2)kickoff();
  ws.send(JSON.stringify({type:"welcome",id,slot}));broadcast();
  ws.on("message",raw=>{
    let m;try{m=JSON.parse(raw)}catch{return}
    const p=S.players[id];if(!p)return;
    if(m.type==="input")p.input={left:!!m.input.left,right:!!m.input.right,jump:!!m.input.jump,pass:!!m.input.pass};
  });
  ws.on("close",()=>{clients.delete(id);delete S.players[id];if(S.ball.owner===id)S.ball.owner=null;S.message="Opponent left. Waiting for another player...";broadcast();});
});
setInterval(()=>{
  const ids=[...clients.keys()];
  for(const id of ids){
    const p=S.players[id];if(!p)continue;const i=p.input;
    if(i.left){p.vx-=0.45;p.dir=-1} if(i.right){p.vx+=0.45;p.dir=1}
    p.vx*=0.82;p.vx=clamp(p.vx,-4.5,4.5);p.x=clamp(p.x+p.vx,20,W-20);
    if(i.jump&&!p._jumpDown&&p.y>=FLOOR){p.vy=-10}
    p._jumpDown=i.jump;p.vy+=0.55;p.y=clamp(p.y+p.vy,90,FLOOR);
    if(p.y>=FLOOR){p.y=FLOOR;p.vy=0}
    if(i.pass&&!p._passDown&&S.ball.owner===id){
      S.ball.owner=null;S.ball.x=p.x+p.dir*22;S.ball.y=p.y-30;S.ball.vx=p.dir*9;S.ball.vy=-2;S.message="PASS IN THE AIR!";
    }
    p._passDown=i.pass;
  }
  const owner=S.ball.owner&&S.players[S.ball.owner];
  if(owner){S.ball.x=owner.x+owner.dir*22;S.ball.y=owner.y-30;}
  else{
    S.ball.x+=S.ball.vx;S.ball.y+=S.ball.vy;S.ball.vy+=0.28;S.ball.vx*=0.99;
    for(const id of ids){const p=S.players[id];if(p&&Math.hypot(p.x-S.ball.x,p.y-25-S.ball.y)<32){S.ball.owner=id;p.hasBall=true;S.ball.vx=S.ball.vy=0;S.message=p.name+" CAUGHT IT!";break;}}
    if(S.ball.y>FLOOR+25){S.ball.y=FLOOR-18;S.ball.vy=0;S.ball.vx*=0.65;}
  }
  if(owner&&ids.length===2){
    const defender=ids.map(id=>S.players[id]).find(p=>p&&p.id!==owner.id);
    if(defender&&Math.abs(defender.x-owner.x)<30&&Math.abs(defender.y-owner.y)<35){
      S.ball.owner=null;owner.hasBall=false;S.message="BIG TACKLE!";setTimeout(()=>{if(clients.size===2)kickoff()},850);
    }
    if((owner.slot===0&&owner.x>850)||(owner.slot===1&&owner.x<50)){
      S.score[owner.slot]++;S.ball.owner=null;owner.hasBall=false;S.message="TOUCHDOWN!!!";setTimeout(()=>{if(clients.size===2)kickoff()},1200);
    }
  }
  broadcast();
},1000/30);
server.listen(process.env.PORT||3000,()=>console.log("Retro Football running"));
