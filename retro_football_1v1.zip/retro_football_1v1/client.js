const c=document.getElementById("field"),g=c.getContext("2d");g.imageSmoothingEnabled=false;
const keys={left:false,right:false,jump:false,pass:false};let myId=null,state=null;
const ws=new WebSocket((location.protocol==="https:"?"wss://":"ws://")+location.host);
ws.onopen=()=>document.getElementById("status").textContent="ONLINE";
ws.onclose=()=>document.getElementById("status").textContent="DISCONNECTED";
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==="full"){document.getElementById("status").textContent="MATCH FULL";return}if(m.type==="welcome"){myId=m.id;document.getElementById("status").textContent="YOU ARE PLAYER "+(m.slot+1)}if(m.type==="state"){state=m.state;document.getElementById("s0").textContent=state.score[0];document.getElementById("s1").textContent=state.score[1];document.getElementById("message").textContent=state.message}};
function send(){if(ws.readyState===1)ws.send(JSON.stringify({type:"input",input:keys}))}
const map={"a":"left","arrowleft":"left","d":"right","arrowright":"right","w":"jump","arrowup":"jump"," ":"pass"};
onkeydown=e=>{let k=map[e.key.toLowerCase()];if(k){keys[k]=true;send();e.preventDefault()}};
onkeyup=e=>{let k=map[e.key.toLowerCase()];if(k){keys[k]=false;send();e.preventDefault()}};
document.querySelectorAll("[data-k]").forEach(b=>{let k=b.dataset.k;let down=e=>{e.preventDefault();keys[k]=true;send()},up=e=>{e.preventDefault();keys[k]=false;send()};b.onpointerdown=down;b.onpointerup=up;b.onpointerleave=up;b.onpointercancel=up});
function rect(x,y,w,h,col){g.fillStyle=col;g.fillRect(Math.round(x),Math.round(y),w,h)}
function drawPlayer(p){
 const x=Math.round(p.x),y=Math.round(p.y);
 // chunky pixel-art football player
 rect(x-12,y-30,24,25,p.slot===0?"#d93434":"#286bd0");
 rect(x-10,y-38,20,10,"#f0c49a");rect(x-13,y-41,26,7,"#242b36");rect(x-16,y-37,5,8,"#242b36");
 rect(x-10,y-5,8,17,"#eee");rect(x+3,y-5,8,17,"#eee");
 rect(x-11,y+10,9,5,"#252b35");rect(x+3,y+10,10,5,"#252b35");
 rect(x-16,y-26,7,15,p.slot===0?"#a91f2c":"#174c9d");rect(x+9,y-26,7,15,p.slot===0?"#a91f2c":"#174c9d");
 if(p.id===myId){rect(x-19,y-53,38,3,"#ffe36c")}
 g.fillStyle="#fff";g.font="bold 12px monospace";g.textAlign="center";g.fillText(p.slot===0?"1":"2",x,y-14);
}
function draw(){
 rect(0,0,900,500,"#35964b");
 // crowd and stadium border
 rect(0,0,900,48,"#253047");rect(0,452,900,48,"#253047");
 for(let x=8;x<900;x+=18){rect(x,10,8,8,x%3?"#e7e7e7":"#ffcf62");rect(x,470,8,8,x%4?"#e7e7e7":"#ffcf62")}
 // field stripes
 for(let x=0;x<900;x+=100)rect(x,48,100,404,x%200===0?"#3ca653":"#35964b");
 rect(0,48,48,404,"#2759a8");rect(852,48,48,404,"#a72d36");
 for(let x=50;x<900;x+=50){rect(x,48,3,404,"#d8efd2");}
 rect(48,48,804,3,"#fff");rect(48,449,804,3,"#fff");
 g.fillStyle="#fff";g.font="bold 20px monospace";g.textAlign="center";
 g.save();g.translate(24,250);g.rotate(-Math.PI/2);g.fillText("BLUE END ZONE",0,0);g.restore();
 g.save();g.translate(876,250);g.rotate(Math.PI/2);g.fillText("RED END ZONE",0,0);g.restore();
 for(let x=100;x<850;x+=100){g.fillStyle="rgba(255,255,255,.9)";g.font="bold 14px monospace";g.fillText(String(Math.round((x-450)/10+50)),x,70)}
 if(state){
  Object.values(state.players).forEach(drawPlayer);
  const b=state.ball;rect(b.x-10,b.y-5,20,10,"#7a3f1b");rect(b.x-5,b.y-2,10,3,"#fff");
  if(Object.keys(state.players).length<2){g.fillStyle="#fff";g.font="bold 26px monospace";g.fillText("WAITING FOR PLAYER 2",450,245)}
 }else{g.fillStyle="#fff";g.font="bold 26px monospace";g.fillText("CONNECTING TO GAME...",450,245)}
 requestAnimationFrame(draw);
}draw();